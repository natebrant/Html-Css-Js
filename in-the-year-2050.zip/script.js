let name = prompt("name");
let game = prompt("favort game");
let time = prompt("how long a week do you play this game");
  $("#test").click(function() {

  console.log("work")
  var name = $("#name").text
  var game = $("#game").text
  var time = $("#time").text
  console.log(name + " you have played " + game + " for " + (time*(28)*52.1) + " Hours by the year 2050")}