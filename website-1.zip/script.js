test()
var x = 0
var y = 0
var top = 0
function test(){
  x +=1}
//setInterval(test,10)}
  time()

function time(){
  document.getElementById("test").innerHTML = x/y
  y+=1;
  // if(top<x/y){
  //   top=x/y;
  //   console.log(top);}
  setTimeout(time,1000);
  
}

console.log($(".body").css("background-color"));